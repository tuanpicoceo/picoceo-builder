# Bambu Lab CyberBrick Hardware 3D Models & Reference Designs
Generated according to CyberBrick_Robotics_Hardware_and_3D_Design_Guide.pdf.

## Included Components
- B-XA003_ESP32_Core.stl: ESP32-C3 Core Controller (32-bit RISC-V @160MHz controller with USB-C and stacking bus)
- B-XA004_Power_Shield.stl: Receiver & Power Shield (4x Servo headers S1-S4, D1 addressable LED port, M2.5 23x24mm pitch)
- B-PG001_180_Servo.stl: 180° Positional Micro Servo (1.2 kgf·cm @ 6V, 21T spline Ø4.8mm, ear span 32.4mm, ear pitch 27.8mm)
- B-PG002_Continuous_Servo.stl: 360° Continuous Micro Servo (120 RPM @ 6V, 1.6 kgf·cm, 21T micro spline)
- B-GM001_Geared_Motor.stl: 030 High-Torque Geared Motor (180 RPM @ 6V, 2.4 kgf·cm, Ø3.0mm D-shaft with 2.5mm flat)
- B-PC003_2S_Battery.stl: 7.4V 800mAh 2S Li-ion Battery (Twin 14500 Li-ion cells, integrated BMS, XH2.54 2-pin connector)
- B-XA007_Toggle_Switch.stl: Slide Toggle Power Switch (Rated 50V/0.5A, SPDT toggle, 1x M2.5 ear mounting hole)
- B-XA006_LED_Hub.stl: LED Distribution Hub PCB (6-branch WS2812 splitter with M2.5 center mounting boss)
- B-KB003_RGBW_LED.stl: WS2812 RGBW LED Module (Addressable 5050 package, 6.0 x 6.0 x 2.8 mm)
- Horn_21T_Micro_Spline.stl: 21T Micro Spline Single-Arm Horn (Standard CyberBrick 21T horn with pilot holes at 10.0 and 13.5 mm)
- Reference_Under_Hood_Tongue_Cheek_Clamp.stl: Under-Hood Cross-Clamp Joint (Guide s.10 Figure 4.1 Tongue & Cheek Cross-Lock joint with captive M3 nut)

All files are binary STLs ready for import into Bambu Studio, OrcaSlicer, CAD, or 3D visualizers.
